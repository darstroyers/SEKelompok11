package com.example.nihonvent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class EventList extends AppCompatActivity {
    String Category[] = {"Festival", "Festival", "Festival"};
    String Desc [] = {"Minazuki Festival is Coming soon", "Indonesia Comic Con will be avaible", "Mukashi Festival"};
    String Imagelist[] = {"bannerbiru", "bannerijo", "bannerpink"};
    int ImageIndicator [] = {R.drawable.bannerbiru, R.drawable.bannerijo, R.drawable.bannerpink};

    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);
        listView = (ListView) findViewById(R.id.list_view_event);
        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(),Imagelist,ImageIndicator,Category,Desc);
        listView.setAdapter(customAdapter);
        listView.setClickable(true);
//        listView.setOnClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Intent i = new Intent( EventList.this,MainActivity.class );
//                startActivity(i);
//            }
//        });
        View HeaderLayout= findViewById(R.id.headerLayout);
        ImageButton notif = HeaderLayout.findViewById(R.id.imageButton);
        notif.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), Notifikasi.class));
        });
        Button categoryl = findViewById(R.id.button3);
                categoryl.setOnClickListener(v -> {
                    startActivity(new Intent(getApplicationContext(), category.class));

                });



        //////////////////////////bottommm///////////////

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottomNavigationView);
        // Set Home selected
        bottomNavigationView.setSelectedItemId(R.id.eventButton);
        // Perform item selected listener
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if(itemId == R.id.eventButton){
                    return true;
                } else if (itemId == R.id.homeButton) {
                    startActivity(new Intent(getApplicationContext(), home.class));
                    overridePendingTransition(0,0);
                    return true;
                } else if (itemId == R.id.ticketButton) {
                    startActivity(new Intent(getApplicationContext(), TicketPage.class));
                    overridePendingTransition(0,0);
                    return true;
                }return false;
            }
        });

        ////////////////////////////



    }
}