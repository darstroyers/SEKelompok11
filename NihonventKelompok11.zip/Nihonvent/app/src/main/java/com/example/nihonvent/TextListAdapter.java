package com.example.nihonvent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class TextListAdapter extends BaseAdapter {

    Context context;
    String listText[];
    LayoutInflater inflater;
    public TextListAdapter(Context ctx, String [] Text){
        this.context = ctx;
        this.listText = Text;
        inflater = LayoutInflater.from(ctx);
    }

    @Override
    public int getCount() {
        return listText.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.notif_list, null);
        TextView txtview1 = (TextView) convertView.findViewById(R.id.NotifText);
        txtview1.setText(listText[position]);
        return convertView;
    }
}
