package com.example.nihonvent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {
    Context context;
    String listImage[];
    String listDesc[];
    String listCategory[];

    int images[];
    LayoutInflater inflater;
    public CustomAdapter(Context ctx, String [] Imagelist, int [] ImageIndicator, String[] Category, String[] Desc){
        this.context = ctx;
        this.listImage = Imagelist;
        this.listDesc = Desc;
        this.listCategory = Category;
        this.images = ImageIndicator;
        inflater = LayoutInflater.from(ctx);
    }

    @Override
    public int getCount() {
        return listImage.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.list_view_row, null);
        TextView txtview1 = (TextView) convertView.findViewById(R.id.textView5);
        TextView txtview2 = (TextView) convertView.findViewById(R.id.textView8);
        TextView txtview3 = (TextView) convertView.findViewById(R.id.textView9);
        ImageView Img = (ImageView) convertView.findViewById(R.id.imageView6);
        txtview1.setText(listImage[position]);
        txtview2.setText(listDesc[position]);
        txtview3.setText(listCategory[position]);
        Img.setImageResource(images[position]);
        return convertView;
    }
}
